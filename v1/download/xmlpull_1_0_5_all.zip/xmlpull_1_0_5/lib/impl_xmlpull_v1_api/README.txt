Copy JAR file with implementation of XMLPULL V1 API here 
to be used automatically by run system.

For list of implementations see: http://www.xmlpull.org/impls.shtml
