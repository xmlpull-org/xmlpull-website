=============================================
Oracle StAX Pull Parser for JSR 173 Preview
=============================================

Standalone Distribution Readme 

Contents
--------

    * Introduction
    * Pre-Requisites
    * Basic Installation 
    * Documentation
    * Running the demo
    
Introduction
------------
    
The Oracle StAX Pull Parser implementation for JSR 173 standalone preview
distribution provides a xmlpull.jar, two sample java files, one sample XML file and the readme  
as a simple zip file. 

Pre-Requisites
--------------
    
In order to use Oracle Pull Parser implementation for JSR 173, you must have a Java2 Standard Edition 
(J2SE) version 1.4.1 or later, the JSR173 jar(download from http://jcp.org/aboutJava/communityprocess/first/jsr173/index.html)
and Oracle XDK(xmlparserv2.jar) installed on your system. 

Basic Installation
------------------

To install, unzip the xmlpull.zip file using the archive utility
of your choice. The jar utility in your J2SE installation can also be used. 

The following files will be extracted:

    xmlpull.jar
    StAX_Cursor.java
    StAX_Iterator.java
    books.xml

Documentation
-------------

There is no official documentation available for this early release.

Running the Demo
-----------------------------------------------
You have to set the jdk1.4 or later, xmlpull.jar and xmlparserv2.jar in your classpath.  
And put the books.xml under the same directory as the sample java files.

1.Compile
   javac StAX_Cursor.java
   javac StAX_Iterator.java
2.Run
   java -Djavax.xml.stream.XMLInputFactory=oracle.xml.stream.OracleInputFactory StAX_Cursor
   java -Djavax.xml.stream.XMLInputFactory=oracle.xml.stream.OracleInputFactory StAX_Iterator

Copyright 2003 Oracle Corporation. All Rights Reserved.              
