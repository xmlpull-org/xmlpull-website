import java.io.FileInputStream;
import javax.xml.stream.*;
import javax.xml.stream.events.*;
import javax.xml.namespace.QName;

public class StAX_Iterator {

   public static void main(String args[]) throws Exception {
      XMLEventReader eventReader =
	   XMLInputFactory.newInstance().createXMLEventReader(
		new FileInputStream("books.xml"));
      while(eventReader.hasNext()) {
	   XMLEvent event = eventReader.next();
	   if (event instanceof StartElement && 	((StartElement)event).getName().getLocalPart().equals("title")) {
		System.out.println( ((Characters)eventReader.next()).getData());
	   }
      }
   }
}
