import java.io.FileInputStream;
import javax.xml.stream.*;
import javax.xml.stream.events.XMLEvent;

public class StAX_Cursor {

   public static void main(String args[]) throws Exception {
      XMLStreamReader reader =
	   XMLInputFactory.newInstance().createXMLStreamReader(
		new FileInputStream("books.xml"));
      while(reader.hasNext()) {
	   int eventType = reader.next();
	   if (eventType == XMLEvent.START_ELEMENT && 
			reader.getLocalName().equals("title")) {
		  reader.next();
		  System.out.println(reader.getText());
	   }
      }
   }
}
